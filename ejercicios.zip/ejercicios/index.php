<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        <form action="saludo.php" method="post">
            nombre: <input type="text" name="nombre">
            <input type = "submit"> 
        </form>
        <form action="conversion.php" method="post">
            ingrese la temperatura y seguido ponga los grados usando K, C o F: <input type="text" name="tipo">
            <br>ingrese los grados en que lo desea convertir usando K, C o F: <input type="text" name="tipo2">
            <input type = "submit">
        </form> 
        <form  action="cadena.php" method="post">
            ingrese la cadena: <input type="text" name="cadena">
            <input type = "submit">
        </form>
        <form  action="calculadora.php" method="post">
            ingrese el primer número: <input type="text" name="dato1">
            <br>ingrese el segundo número: <input type="text" name="dato2">
            <br>seleccione el tipo de operación poniendo "S, R, M, o D": <input type="text" name="dato3">
            <br><input type = "submit">
        </form> 
        <form  action="numero.php" method="post">
            ingrese el primer número: <input type="text" name="dato1">
            <br>ingrese el segundo número: <input type="text" name="dato2">
            <br>ingrese el tercer número: <input type="text" name="dato3">
            <br><input type = "submit">
        </form>
        <form>
            pulsa el "link" para ver un listado de los primeros 20 números pares y primeros 20 impares 
            <a href="paresimpares.php"><p>link</a>
        </form>
        <form action="cadena2.php" method="post">
            Ingrese una cadena: <input type="text" name="cadena">
            <input type = "submit"> 
        </form>
        <form action="edad.php" method="post">
            Ingrese su edad: <input type="text" name="edad">
            <input type = "submit"> 
        </form>
        <form action="multiplicar.php" method="post">
            Ingrese un número para conseguir una tabla de multiplicar: <input type="text" name="dato1">
            <br>Ingrese hasta que número quiere la tabla del número anterior: <input type="text" name="dato2">
            <input type = "submit"> 
        </form>
        <form action="texto.php" method="post">
            Ingrese un texto para contar las palabras: <input type="text" name="texto">
            <input type = "submit"> 
        </form>
        <form action="invertir.php" method="post">
            Ingrese un texto para invertirlo: <input type="text" name="texto">
            <input type = "submit"> 
        </form>
        <form action="dinero.php" method="post">
            Ingrese una cantidad y agregele €, $ o Q al inicio: <input type="text" name="tipo">
            <br>En que desea convertirlo €, $ o Q: <input type="text" name="conversion">
            <input type = "submit"> 
        </form>
        <form action="imc.php" method="post">
            Ingrese su peso: <input type="text" name="peso">
            <br> Ingrese su altura en cm: <input type="text" name="altura">
            <input type = "submit"> 
        </form>
        <form action="contraseña.php" method="post">
            Ingrese la cantidad de dígitos de su nueva contraseña aleatoria: <input type="text" name="digitos">
            <input type = "submit">
        </form>
        <form action="texto2.php" method="post">
            Ingrese un texto para contar los caracteres: <input type="text" name="texto">
            <input type = "submit"> 
        </form>
        <form action="añobisiesto.php" method="post">
            Ingrese un año para determinar si es bisiesto o no: <input type="text" name="año">
            <input type = "submit"> 
        </form>
        <form action="fechanacimiento.php" method="post">
            Ingrese el año en que nació: <input type="text" name="año">
            <br>Ingrese el mes en que nació: <input type="text" name="mes">
            <br>Ingrese el día en que nació: <input type="text" name="dia">
            <input type = "submit"> 
        </form>
        <form action="correo.php" method="post">
            Ingrese su correo electrónico: <input type="text" name="correo">
            <input type = "submit"> 
        </form>
        <form action="lenguaje.php" method="post">
            Ingrese un texto usando lenguaje soez: <input type="text" name="lenguaje">
            <input type = "submit"> 
        </form>
        <form action="sorteo.php" method="post">
            Ingrese su nombre para participar en el sorteo de 100 personas: <input type="text" name="sorteo">
            <input type = "submit"> 
        </form>
        <form action="figura.php" method="post">
            Ingrese la figura usando Ci, Cu o RE: <input type="text" name="tipo">
            <input type = "submit"> 
        </form>
    <body>
</html>