<?php 
require_once "index.php"; 
$lenguaje = $_POST['lenguaje']; 
$texto = str_replace(['puta', 'mierda', 'coño', 'pendejo', 'idiota', 'negro', 'marica', 'culiao', 'triplehijueputa', 'verga', 'cerote', 'estupido'], '****', $lenguaje);
echo "Escribiste: $texto";
?>